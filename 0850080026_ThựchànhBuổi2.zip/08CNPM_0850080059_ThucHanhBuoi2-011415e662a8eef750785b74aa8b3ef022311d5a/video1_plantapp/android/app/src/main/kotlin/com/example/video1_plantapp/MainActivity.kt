package com.example.video1_plantapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
