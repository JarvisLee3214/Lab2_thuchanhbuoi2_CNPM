package com.example.video4_covidapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
