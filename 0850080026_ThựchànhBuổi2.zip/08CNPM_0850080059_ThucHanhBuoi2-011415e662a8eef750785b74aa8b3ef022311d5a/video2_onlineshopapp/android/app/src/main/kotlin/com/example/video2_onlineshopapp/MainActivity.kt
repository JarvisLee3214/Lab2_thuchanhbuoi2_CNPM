package com.example.video2_onlineshopapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
