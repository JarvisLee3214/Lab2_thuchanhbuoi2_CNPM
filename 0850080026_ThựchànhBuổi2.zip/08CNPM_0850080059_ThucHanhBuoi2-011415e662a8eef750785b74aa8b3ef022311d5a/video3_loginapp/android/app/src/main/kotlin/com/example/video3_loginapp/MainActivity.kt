package com.example.video3_loginapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
